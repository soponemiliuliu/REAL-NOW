REAL NOW — versiunea 0.6.0

Include navigare pe trei niveluri (categorii > subcategorii > pagina dedicata), cautare de locatii pe harta OpenStreetMap/Nominatim, pin mutabil, chat local separat pe subcategorie, raportari si fotografii locale, plus mascota jder animata discret.

LIMITARI IMPORTANTE: aceasta este o versiune demonstrativa locala. Postarile, fotografiile si mesajele raman pe dispozitivul unde au fost create; nu exista conturi, server comun sau sincronizare intre utilizatori. Cautarea hartii necesita internet.
