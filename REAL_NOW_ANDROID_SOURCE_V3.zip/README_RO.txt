REAL NOW v0.3.0 — prototip multiplatformă

CONȚINUT
- index.html + manifest.webmanifest + sw.js: versiune web instalabilă (PWA)
- app/: proiect Android WebView pentru generarea APK
- .github/workflows/build-apk.yml: flux GitHub Actions pentru APK

FUNCȚII ÎN PROTOTIP
Categorii și subcategorii, filtrare/căutare, raportări și întrebări, fotografii locale, hartă OpenStreetMap cu pin mutabil, conversații locale asociate fiecărei postări, stocare locală pe dispozitiv.

LIMITĂRI IMPORTANTE
Această versiune NU are încă server/backend. Postările, fotografiile și chatul sunt salvate numai pe dispozitivul curent și nu sunt partajate cu alți utilizatori sau sincronizate între dispozitive. Nu există încă autentificare, mesagerie privată reală, moderare centrală, publicitate activă sau sistem de plăți. Harta și biblioteca Leaflet necesită internet.

PWA: publicați fișierele din rădăcina arhivei pe un host HTTPS (de exemplu GitHub Pages), apoi deschideți adresa pe telefon/calculator și folosiți „Add to Home Screen” / „Install”.
Android: proiectul Gradle este în rădăcina arhivei. Workflow-ul GitHub Actions din .github/workflows poate construi APK debug după încărcarea proiectului în repository.

Costuri: nu sunt configurate servicii plătite. Hărțile OpenStreetMap au politici de utilizare; pentru trafic mare va trebui aleasă o soluție potrivită.
