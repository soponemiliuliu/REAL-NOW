REAL NOW – proiect Android pentru generarea unui APK de test

IMPORTANT: acest pachet NU este încă un APK instalabil. Conține proiectul Android și un flux automat de compilare în GitHub Actions, astfel încât APK-ul să poată fi generat în cloud fără calculator personal.

CE INCLUDE
- Aplicația web REAL NOW împachetată într-un WebView Android.
- Salvare locală prin DOM storage / localStorage.
- Permisiune opțională pentru locație.
- Nume aplicație: REAL NOW.
- Workflow GitHub Actions pentru compilarea APK-ului de test.

LIMITĂRI MVP
- Nu există server comun sau sincronizare între utilizatori.
- Datele rămân pe dispozitiv.
- Nu există conturi, notificări, hartă, moderare centrală, reclame sau plăți.
- APK-ul generat de workflow este un APK debug pentru testare, nu o versiune pregătită pentru Google Play.

GENERARE APK FĂRĂ PC (cu telefonul)
1. Creează un cont gratuit pe github.com și un repository nou, de exemplu real-now-android.
2. În repository, folosește Add file > Upload files și încarcă fișierul REAL_NOW_ANDROID_SOURCE.zip în rădăcina repository-ului.
3. Creează fișierul .github/workflows/build-apk.yml și copiază conținutul workflow-ului din pachetul sursă (fișierul .github/workflows/build-apk.yml).
4. Deschide fila Actions, alege Build REAL NOW APK și apasă Run workflow.
5. Când apare rularea verde, deschide-o și descarcă artifact-ul REAL-NOW-Android-debug-APK.
6. Extrage artifact-ul și instalează app-debug.apk. Android poate cere permisiunea de instalare din sursa folosită pentru descărcare.

Dacă ai nevoie, te pot ghida pas cu pas pe telefon, cu fiecare apăsare.
